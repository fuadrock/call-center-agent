export const environment = {
  production: true,
  defaultauth: 'fake-backend',
  base_url: 'https://365smartconnect.asiamediatel.com/callcenter/api/',

  firebaseConfig: {
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
    measurementId: ''
  }
};
